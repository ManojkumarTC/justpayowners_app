

const PropertySubHeader = ({ Tilte }) => {
    return (
        <div className="card-header">
            <h2 className="card-title">{Tilte}</h2>           
        </div>
    )
}
export default PropertySubHeader