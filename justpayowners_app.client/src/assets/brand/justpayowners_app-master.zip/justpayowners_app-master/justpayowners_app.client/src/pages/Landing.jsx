import React, { useEffect, useState } from "react";


export const landingLoader = async () => {
  // const response = await axios(
  //   `http://justpayowners.runasp.net/WeatherForecast`
  // );
  const data = [];
  return { products: data };
};

const Landing = () => {

  return (<div className="container">
    HI</div>
  );
};

export default Landing;
