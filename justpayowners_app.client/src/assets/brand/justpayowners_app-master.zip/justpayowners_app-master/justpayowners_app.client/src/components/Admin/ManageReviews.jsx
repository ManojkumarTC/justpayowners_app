import React from 'react'

const ManageReviews = () => {
  return (
    <div>ManageReviews</div>
  )
}

export default ManageReviews