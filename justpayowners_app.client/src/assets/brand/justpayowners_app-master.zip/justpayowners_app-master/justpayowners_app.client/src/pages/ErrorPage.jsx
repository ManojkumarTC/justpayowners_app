

function ErrorPage() {
    return (
        <>Error</>
    );
}

export default ErrorPage;