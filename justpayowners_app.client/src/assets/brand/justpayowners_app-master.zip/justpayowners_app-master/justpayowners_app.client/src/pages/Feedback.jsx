

import Jsonfooter from '../mockdata/footerData.json';
import { NavLink, Link } from 'react-router-dom';
const Feedback = function () {
    console.log("Feedback - Render")
    return (<>
        <main className="site-main content-area">
            <div className="container">
                <div className="row">
                    <div className="col-lg-12 col-sm-12 col-12">
                        <div className="page-content-block">
                            <div className="col-md-12 rtcl-login-form-wrap">
                                <h4>About us</h4>




                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>      
    </>
    );
};

export default Feedback;
